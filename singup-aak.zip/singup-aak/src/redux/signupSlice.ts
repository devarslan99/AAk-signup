import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";

interface SignupPayload {
    user_type: string;
    first_name: string;
    last_name: string;
    username: string;
    email: string;
    password: string;
    country: Country;
}

interface Country {
    name: string;
}


interface SignupState {
    loading: boolean;
    error: string | null;
    success: boolean;
}

const initialState : SignupState = {
    loading: false,
    error: null,
    success: false,
}


export const signupUser = createAsyncThunk(
    'auth/signup',
    async(signupDate: SignupPayload, {rejectWithValue}) => {
        try {
            const response = await axios.post('https://django-dev.aakscience.com/signup/', signupDate);
            return response.data
        } catch (error: any) {
            return rejectWithValue(error.response?.data || 'Signup failed')
        }
    }
)

const signupSlice = createSlice({
    name: 'signup',
    initialState,
    reducers:{
        resetSignupState: (state) => {
            state.loading= false;
            state.error = null;
            state.success=false
        },
    },
    extraReducers:(builder) => {
        builder.addCase(signupUser.pending, (state) => {
            state.loading = true;
            state.error= null;
        })
        .addCase(signupUser.fulfilled, (state)=>{
            state.loading=false;
            state.success=true;
            state.error= null
        })
        .addCase(signupUser.rejected, (state, action) => {
            state.loading= false;
            state.error= action.payload as string
        })
    }
});

export const {resetSignupState} = signupSlice.actions;
export default signupSlice.reducer
